# Spoof Timezone

Alters browser timezone to a random or user-defined value.


How to report a bug:
  * For general question please use the review section of the [FAQs page](https://add0n.com/spoof-timezone.html)
 * For technical question please open a new bug report here
